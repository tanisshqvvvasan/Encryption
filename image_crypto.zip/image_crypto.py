import os
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
from cryptography.hazmat.primitives import hashes, padding
from cryptography.hazmat.backends import default_backend
import getpass

def generate_key(password: str, salt: bytes) -> bytes:
    """Derive a secure encryption key from a password using PBKDF2."""
    kdf = PBKDF2HMAC(
        algorithm=hashes.SHA256(),
        length=32,  # AES-256 key size
        salt=salt,
        iterations=100000,  # Slow down brute-force attacks
        backend=default_backend()
    )
    return kdf.derive(password.encode())

def encrypt_image(input_path: str, output_path: str, key: bytes) -> None:
    """Encrypt an image file using AES-GCM."""
    iv = os.urandom(12)  # GCM recommended IV size
    cipher = Cipher(algorithms.AES(key), modes.GCM(iv), backend=default_backend())
    encryptor = cipher.encryptor()

    with open(input_path, 'rb') as f:
        plaintext = f.read()

    ciphertext = encryptor.update(plaintext) + encryptor.finalize()

    # Save IV + ciphertext + tag
    with open(output_path, 'wb') as f:
        f.write(iv + encryptor.tag + ciphertext)

def decrypt_image(input_path: str, output_path: str, key: bytes) -> None:
    """Decrypt an image file encrypted with AES-GCM."""
    with open(input_path, 'rb') as f:
        data = f.read()
    
    iv, tag, ciphertext = data[:12], data[12:28], data[28:]
    cipher = Cipher(algorithms.AES(key), modes.GCM(iv, tag), backend=default_backend())
    decryptor = cipher.decryptor()

    plaintext = decryptor.update(ciphertext) + decryptor.finalize()

    with open(output_path, 'wb') as f:
        f.write(plaintext)

def main():
    print("Image Encryption/Decryption Framework")
    print("1. Encrypt an image")
    print("2. Decrypt an image")
    print("3. Exit")
    
    while True:
        choice = input("Enter your choice (1-3): ")
        
        if choice == '1':
            password = getpass.getpass("Enter a password to generate the encryption key: ")
            salt = os.urandom(16)  # Random salt for KDF
            key = generate_key(password, salt)
            
            input_path = input("Enter the path to the image to encrypt (e.g., image.png): ")
            output_path = input("Enter the path to save the encrypted image (e.g., encrypted.bin): ")
            
            encrypt_image(input_path, output_path, key)
            with open("salt.bin", 'wb') as f:  # Save salt for decryption
                f.write(salt)
            print(f"Image encrypted successfully! Salt saved to salt.bin")
            
        elif choice == '2':
            password = getpass.getpass("Enter the password used for encryption: ")
            
            try:
                with open("salt.bin", 'rb') as f:
                    salt = f.read()
                key = generate_key(password, salt)
                
                input_path = input("Enter the path to the encrypted image (e.g., encrypted.bin): ")
                output_path = input("Enter the path to save the decrypted image (e.g., decrypted.png): ")
                
                decrypt_image(input_path, output_path, key)
                print("Image decrypted successfully!")
            except FileNotFoundError:
                print("Error: salt.bin not found. Cannot derive key.")
            except Exception as e:
                print(f"Decryption failed: {e}")
                
        elif choice == '3':
            print("Exiting...")
            break
            
        else:
            print("Invalid choice. Try again.")

if __name__ == "__main__":
    main()
